Dutch Station Addition Set Part 2 v0.4
-----------------------------------

Contents:

1 About
2 Requirements
3 Installation
4 Usage
5 License
6 Credits




-------
1 About
-------

The DSA-Part2-set is a station set that can help you create Dutch style stations and waypoints.
To make most use of the set, place it directly below the original Dutch Station Addition Set (Part1) in the GRF-list.
See development thread for more information and screenshots: http://www.tt-forums.net/viewtopic.php?f=26&t=74530

Dutch Station Addition Set Part 2 v0.4
Name: dstatadd_part2_v0_4.grf
Version:  0.4
GRF ID:   50 4A 01 12





--------------
2 Requirements
--------------

Recommended is to use the latest (nightly)release of OpenTTD. Also this set will look at it's best when combined with the Total Bridge Renewal set and the Metro Track Set.




--------------
3 Installation
--------------

Copy the .grf file to the OpenTTD data directory. The OpenTTD readme explains where you can find this directory.

The final step is to activate the station tiles.
This is done via the NewGRF Settings window, which is explained here:
http://wiki.openttd.org/NewGRF.
Now you can use the stations in your new games.



-------
4 Usage
-------

These stationtiles can be used to create Dutch style stations and waypoints.
Place the GRF directly below the original Dutch Stations Addition Set (Part1) in your GRF-list.


---------
5 License
---------

DSA-Part2-set for OpenTTD
Copyright (C) 2017 Quast65

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



---------
6 Credits
---------

- Silverx50, for many new Dutch Station graphics (GPLv2)
- GarryG, for the U-shaped Overpass Stairs graphics (GPLv2)
- sanderNL, for the Hanzelijn Stations (GPLv2)
- luxtram, for some handy drawing tricks and tips
- All others, who have pointed out bugs or gave good hints and suggestions ;-)
- Modification to graphics, new graphics, modification to code and new code by Quast65 (GPLv2)

Credits from the original Dutch Station Addition Set:
- Original Dutch stations and platforms by the Developers of the Dutch Station Set (GPLv2)
- Original railroad crossing lights by Purno (GPLv2)
- Original 60's style station by Caelan (GPLv2)
- Original TTRS-road by Zimmlock (GPLv2)
- Original UK-road by Born Acorn (GPLv2)
- Original Open-GFX graphics by the Developers of the Open-GFX set (GPLv2)
- Original code by the Developers of the Dutch Station Set (GPLv2)
- Original Delft station, Eindhoven station, Douma style stations, Sextant station, KNLS-1 station and HESM-1 station by ths (GPLv2)
- Original Modern CTA, modification to Old CTA (so it has a black pole) and Amsterdam CS (based on an original design by Caelan) by YSH (GPLv2)
- Modification to graphics, new graphics, modification to code and new code by Quast65 (GPLv2)

Also many thanks to FooBar for putting me on the right track towards a tile that changes it's appearance when a train passes through it and especially to OzTrans for his help with that code!
