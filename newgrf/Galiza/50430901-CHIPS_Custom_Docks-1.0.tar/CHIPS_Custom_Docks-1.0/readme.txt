=======================
CHIPS CUSTOM DOCKS v1.0
=======================
20 January 2018


-----
ABOUT
-----

This GRF provides new dock graphics for OpenTTD, as well as optional buoys
and GUI icons. Graphics are in the style of FIRS Industry Replacement Set,
CHIPS Station Set and Squid Ate FISH (all created by andythenorth and
others), however none of those sets are required and you can use this GRF
on its own if you prefer.

Docks consist of two different tiles, and using parameters you can choose
each tile from a selection of twelve. A total of 144 unique combinations
are possible so you can style your docks any way you like! Unfortunately
the game only allows for one style of dock at a time.


----------
PARAMETERS
----------

There are currently five parameters:

* Coast tile:  Choose the coast tile (i.e. the part of the dock that sits
               on land) from one of twelve different options.

* Water tile:  Choose the water tile (i.e. the part of the dock that sits
               on water) from one of twelve different options.

* Buoy:        Option to use new buoys; choose between green (from the
               FIRS dredging site) or red, or turn off to disable this
               feature if you prefer to use buoys from the base set or
               another GRF.

* Reserved

* GUI icons:   Option to show dock and buoy in toolbar and cursor. For
               OpenGFX only; turn off to disable this feature and
               use normal base set icons.


-------------
COMPATIBILITY
-------------

CHIPS Custom Docks is coded to replace the default base set graphics.
There are other sets that replace docks and buoys in the same way:
remember that priority is always given to the GRF that is loaded last, so
place CHIPS Custom Docks lower down in your list if that's what you want
to use in the game.

Known GRFS that replace docks or buoys include (but are not necessarily
limited to):

* CHIPS Station Set
* Docks with containers and cranes
* Industrial Stations Renewal
* ISR-style Dock
* Kaijus City Names
* Marico
* New Buoys
* OpenGFX+ Landscape

Some of the above may have parameters to disable certain features.

This GRF is not compatible with TTDPatch.


-------
CREDITS
-------

* Original FIRS, FISH and CHIPS graphics by andythenorth, with
  contributions by DanMacK, Zephyris and others
* Crates and containers by mph and Sanchimaru, originally from
  Industrial Stations Renewal (ISR)
* OpenGFX cursor by bubersson
* Graphics adapted for this GRF by PaulC
* All coding by PaulC


-------------------
FURTHER INFORMATION
-------------------

This GRF is licensed under the GNU General Public License version 2; see
license.txt for full details.

To find source code, screenshots and latest information, please visit the
release topic on TT-Forums.net:

* https://www.tt-forums.net/viewtopic.php?f=67&t=59299

Translations of the language file are always welcome!
