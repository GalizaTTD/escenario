The source is posted on the TT-Forums (subforum: "Graphics Development", topic: "LRVS - Light Road Vehicle Set") for anyone to download.
Also, many thanks to the developers of NML, it made even more complicated coding a breeze!

(c)2010 oberh�mer
The terms of the GPL apply
