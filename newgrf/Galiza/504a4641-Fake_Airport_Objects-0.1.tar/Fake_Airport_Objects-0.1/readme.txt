Fake Airport Objects V0.1
-----------------------------------

Contents:

1 About
2 Requirements
3 Installation
4 Usage
5 License
6 Credits




-------
1 About
-------

The Fake Airport Objects Set provides a lot of (modular) object tiles to create your own fake airport.

See development thread for more information and screenshots: http://www.tt-forums.net/viewtopic.php?f=26&t=62258

Fake Airport Objects V0.1
Name: fakeairportobjects_v0_1.grf
Version:  0.1
GRF ID:   50 4A 46 41





--------------
2 Requirements
--------------

Recommended is to use the latest (nightly)release of OpenTTD.



--------------
3 Installation
--------------

Copy the Fake Aiport Objects .grf file to the OpenTTD data directory. The OpenTTD readme explains where you can find this directory.

The final step is to activate the Fake Airport Objects.
This is done via the NewGRF Settings window, which is explained here:
http://wiki.openttd.org/NewGRF.
Now you can use the Fake Airport Objects in your new games.



-------
4 Usage
-------

These new object tiles can be used to create a totally fake airport. 
Some tiles have multiple graphical representations. 
Place the same tile mutliple times on the same spot to change the graphical representation. 
There are also some animated objects.



---------
5 License
---------

Fake Airport Object Tiles for OpenTTD
Copyright (C) 2015 Quast65

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



---------
6 Credits
---------

Coding, Graphics alterations and new graphics by Quast65: http://www.tt-forums.net/viewtopic.php?f=26&t=57266

Many thanks to:

RSpeed tycoonfreak: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=10175
kamnet: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=31943
ISA: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=8942
maquinista: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=11882
Lamoot: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=10707
Grigory1: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=7300
Hans Kruzer: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=77176
Andrex: http://www.andreszsogon.com/
Uwe: http://www.tt-forums.net/viewtopic.php?t=25634
The Developers of the World Airliners Set: http://www.tt-forums.net/viewtopic.php?f=26&t=39227
The Developers of the Japan Set: http://www.tt-forums.net/viewtopic.php?f=26&t=5358
The Developers of the Total Town Replacement Set: http://www.tt-forums.net/viewtopic.php?f=26&t=8878
The Developers of the OpenGFX-Graphics Base Set: http://www.tt-forums.net/viewtopic.php?f=26&t=38122
The Developers of the IKARUS Set: http://www.tt-forums.net/viewtopic.php?t=44703
The Developers of the Light Road Vehicle Set: http://www.tt-forums.net/viewtopic.php?f=26&t=46583
The Developers of the Bobs Random British Vehicles Set: http://www.tt-forums.net/viewtopic.php?f=26&t=48651
The Developers of the Heavy Equipment Set (HEQS): http://www.tt-forums.net/viewtopic.php?f=36&t=37912

And finally the Simuscape Community for their remarks and suggestions during the initial development of this project: http://www.simuscape.net

If I have forgotten someone, my apologies, please contact me and you will be added: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=57156
 




























