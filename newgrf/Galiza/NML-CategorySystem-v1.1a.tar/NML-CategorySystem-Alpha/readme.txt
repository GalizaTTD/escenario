NML Category System v1.1 alpha
Created by NekoMaster

Users are free to do what ever with NML-CS

[Installation]
1. Extract files to your OpenTTD data\newgrf folder
 For most users it will probably be in your user account folder (Eg. C:\Users\Neko\Documents\OpenTTD)
 For other users it will probably be in your OpenTTD Install (Eg. C:\Program Files\OpenTTD)

2. Use OpenTTD's ingame NewGRF Menu to load up the Category GRF's. Their names are colored green for quick access.

3. Enjoy a organized NewGRF List! Don't forget you can click and drag GRF's in modern OpenTTD builds (I think its been like this since the new NewGRF window)

If there are any problems, or any comments, NML-CS has its own thread on Transport Tycoon Forums
URL : http://www.tt-forums.net/viewtopic.php?f=67&t=65598