Supercheese's Newobjects 0.3.1 Readme
=====================================

This Newobjects set adds various objects to enhance the OTTD experience.

This GRF is available from OTTD's BaNaNaS content downloader; search for "Supercheese" or "SNO".

It can also be downloaded from the following forum thread: http://www.tt-forums.net/viewtopic.php?f=26&t=56780

Please report any and all bugs to that thread.


-------------
Compatibility
-------------

This GRF was generated with NML r2061, and should be compatible with OTTD versions 1.4 and upwards.

If this is not the case, please report it to the forum thread above.


-----------
Object List
-----------

Objects included in version 0.3.1:

	-Circling seagulls (small and large)
	-Ice features
	-Shipwreck
	-New rocks (small & tiny variants)
	-Bare water
	-Docks


There are lots of planned features for the future, too many to list!


-------------------------
GRF Features & Parameters
-------------------------

The seagulls and rocks can be placed on land or water, but not on sloped land (although seagulls can be placed on sloped water). Their groundsprites are snow- and desert-aware, but there is no snow (yet) on top of rocks if they are built above the snowline.
Ice features, the shipwreck, and - naturally - the bare water tile can be placed on water. In order to prevent adjacent tiles being flooded, water objects should be built on bulldozed, bare tiles.

The seagulls, rocks, and ice have elements of randomness to them, either in random graphic variations or starting animations on random frames. Being naturally-occurring objects, they also have zero build cost.

The seagulls will occasionally emit sound effects. If you place a bunch of them together, be prepared for a cacophony! There is a grf parameter to turn the sound effects off, if you'd rather.

The second grf parameter determines whether the objects can be built in a running game, or only in the scenario editor, and if they should be irremovable (like the default lighthouse and transmitter) or not.


-------
License
-------

This GRF is released under the CC BY-NC-SA license. See the license.txt file included in the grf package, or click the
"License" button in OTTD for more information.


-------
Credits
-------

The seagull sound effects were obtained from freesound.org, and are CC BY Licensed: http://www.freesound.org/people/juskiddink/sounds/98479/

The dock sprites were drawn by kamnet, and I edited them slightly into the form shown herein.

The sprites are derived from packages downloaded from the Civilization Fanatics Center: http://forums.civfanatics.com/downloads.php
Non-exhaustive list of packages used:
	-http://forums.civfanatics.com/downloads.php?do=file&id=16264
	-http://forums.civfanatics.com/downloads.php?do=file&id=16285
	-http://forums.civfanatics.com/downloads.php?do=file&id=11804

Many thanks are extended to the developers of OTTD for creating and maintaining such wonderful free software.
