Modular Wider Bridges Set v003
-----------------------------------

Contents:

1 About
2 Requirements
3 Installation
4 Usage
5 License
6 Credits




-------
1 About
-------

MWBS adds three modular bridges that can be used to make wide bridges.
Parameter settings can be used to choose to replace the three Tubular Bridges or to add them as three new bridges.
See development thread for more information and screenshots: https://www.tt-forums.net/viewtopic.php?f=26&t=87655

Modular Wider Bridges Set v003
Name: modular_wider_bridges_v003.grf
Version:  003
GRF ID:   51 42 01 01





--------------
2 Requirements
--------------

Vanilla rail, mono and mlev will not show on the railbridges, use a trackset for that.
For different roads, use a roadset.
Use with JGR PatchPack v0.38.1, so that Towns, GameScripts and AI's wont build these bridges.





--------------
3 Installation
--------------

Copy the .grf file to the OpenTTD data directory. The OpenTTD readme explains where you can find this directory.



-------
4 Usage
-------

MWBS adds three modular bridges that can be used to make wide bridges.


---------
5 License
---------

Modular Wider Bridges Set for JGR PatchPack
Copyright (C) 2020 Quast65

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



---------
6 Credits
---------

- Code & Graphics based on Andrew350's magnificent American Bridges Set and glorious RattRoads.
- Many thanks to WallyWeb for his help with the Menu-sprite code.
- Many thanks to JGR for his modifications of the code.
