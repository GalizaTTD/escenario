THE LIGHTHOUSE SET v. 1.2
16th September 2012


1. About The Lighthouse Set
2. Change Log
3. License
4. Credit


1. ABOUT THE LIGHTHOUSE SET

The Lighthouse Set is an object set (eye candy-set) for openTTD. The
lighthouses are not exact copies of real life lighthouses, but they
are drawn with more or less inspiration from the real lighthouses 
primarily in the Nordic countries. The Lighthouse Set has no other 
function that being an eye candy in openTTD. The Lighthouse Set 
contains by now 14 lighthouses, with either rock/grass or ISR 
(concrete)-basetile. (see 4. Credit)

The lighthouses are drawn and coded by Moluma.

WARNING: It's dissuaded to switch from v. 1.0 to v. 1.2 in game or in
general load the set into an ongoing game!


2. CHANGE LOG

V. 1.0 (16th of April 2012) Initial version containing six lighthouses.
V. 1.1 (Not released - developed into v. 1.2), Improved ingame menu.
V. 1.2 (16th of September 2012)
       - Eight new lighthouses. (Five bigger lighthouses plus three
         smaller canal/inland lighthouses).
       - The Lighthouses names has been replaced by numbers, and the
         original six lighthouses has got new ID's. (Names might be 
         introduced again later on.) 
       - Most Lighthouses has now both rock/grass and ISR basetile. 
       - All Lighthouses are buildable from year 1850 and onwards (no
         withdrawal).
       - Construction price for big lighthouses is now set to ~2500 GBP.
       - Construction price for canal/inland lighthouses is now set to
         ~1250 GBP.
       - Lighthouse no. 4 updated graphical


3. LICENSE

Copyright 2012 Moluma

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


4. CREDITS

THANKS TO:

- Thanks to wallyweb for the "New Objects GRF Coding Guide" which where
  an important source for me when coding the initial version.
- Thanks to Quast65 for coding assistance in v. 1.1/1.2
- Thanks to my muse for ideas and critique

GRAPHICAL CREDITS:

- ISR-basetile, The developers of the Industrial Stations Renewal Set.
- Rock basetile, based on original TTD grapichs.
