============================================================
	VAST Readme
============================================================
A set of non-track tiles designed to make stations look better.
Current version: 0.2.0 [2010-06-20]

----------------
Readme Contents:
----------------
0	License
1	About VAST
	1.1: Parameters
	1.2: Version History
2	Feedback and Bug Reports
3	Contacting the Author / Obtaining the Source

===============================================
	0: License
===============================================
Copyright (C) 2010 David Nicholls

This work is licenced under the Creative Commons Attribution-Non-Commercial-Share Alike 3.0 Unported License. To view a copy of this licence, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California 94105, USA.

===========================================================
	1: About VAST
===========================================================
VAST stands for VAST Assortment of Station Tiles. 
VAST is a set of station tiles intended to complement existing graphics sets in order to create aesthetically pleasing station areas. To do this, it will provide players with generic "aesthetic" tiles that can be used as the player sees fit. This will include gardens, parks, paved areas and station buildings. 

Planned Station Type Categories 

VAST: Grounds
	Plain areas - such as plain grass, concrete and tarmac.
VAST: Paths
	Paved areas of modular tiles.
VAST: Gardens
	Sculpted gardens - flower beds and shrubs.
VAST: Large Gardens
	Large gardens - larger trees, statues and monuments.
VAST: Station Buildings
	Generic station buildings - entrances, car parks etc - not intended to be a full replacement of station building grapics.
VAST: Other Buildings
	Objects that don't belong in the above categories.

---------------
1.1: Parameters
---------------
There are no parameters yet. 

------------------------------------------------------------------------------------------
1.2: Release Version History:
------------------------------------------------------------------------------------------
0.1.0	[2010-06-08]:	Initial release
							>> Implemented Ground, Paths and Gardens
0.2.0	[2010-06-20]:	New features and colour fixes
							>> Fixed Path and brown tile brightness
							>> Added large cypress and smaller shrubs
							>> Renamed cypress and shrubs
							>> Added more variations to Paths

===============================================
	2: Feedback and Bug Reports
===============================================
Please report any bugs in this set's thread at http://www.tt-forums.net/viewtopic.php?f=67&t=48762
Any feedback (good or bad) would be greatly appreciated :)

=======================================================
	3: Contacting the Author / Obtaining the Source
=======================================================
I can be contacted on the Transport Tycoon Forums at http://www.tt-forums.net under the username zero.eight.
The source code (nfo) and graphics (pcx) for this set are available on request.

Enjoy :)
