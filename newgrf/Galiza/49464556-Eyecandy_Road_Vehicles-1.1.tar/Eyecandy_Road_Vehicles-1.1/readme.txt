Eyecandy Road Vehicles 1.1 Readme
=================================

This Eyecandy Road Vehicles GRF adds several eyecandy road vehicles -- meaning they have 0 purchase and running cost and are not intended
to be used as primary transport vectors, but just to improve the looks of cities and roadways.

This GRF is compatible with TownCars AI (http://www.tt-forums.net/viewtopic.php?p=774828) and StreetTraffic (available from the same thread).

This GRF is available from OTTD's BaNaNaS content downloader; search for "Eyecandy Road Vehicles".

It can also be downloaded from the following forum thread: http://www.tt-forums.net/viewtopic.php?f=26&t=56780

Please report any and all bugs to that thread.


-------------
Compatibility
-------------

This GRF was generated with NML r2049, and should be compatible with OTTD versions 1.2 and upwards.

If this is not the case, please report it to the forum thread above.


------------
Vehicle List
------------

Vehicles included in version 1.0:

	-Fire Truck
	-Ambulance
	-Police Car
	-Tow Truck
	-USPS-style Mail Truck
	-Garbage Truck(s)
	-Horse & Rider

Planned Features for sometime in the future:
	-Tow Trucks hauling vehicles behind them when loaded
	-More extra zoom level graphics


-------------------------
GRF Features & Parameters
-------------------------

The Fire Truck, Ambulance, and Police Car feature sirens that, by default, play constantly as they run. These sirens
can be disabled via refit option so that they only play on vehicle startup. Things are coded such that vehicles try
to have different timing offsets so the sirens don't overlap and become too loud, but this still may happen, and so
it is recommended that you limit the number of siren-enabled vehicles that are on-screen at a time.

The parameter "Non-zero purchase costs" raises all vehicles' purchase costs to just above zero.
This is useful if (and perhaps only if) you want to configure TownCars AI parameters to not build these vehicles.

The parameter "Constant sirens enabled on AI Vehicles" is an on/off toggle that is off by default. Turning it on means
AI-built vehicles will play their sirens only on vehicle start. Enabling the parameter means AI vehicles will play sirens constantly.

Some vehicles feature flashing red/blue/yellow lights. The parameter "Disable flashing lights" is an off/on toggle that is off
by default. Turning it on disables the red/blue/yellow flashing lights on the emergency vehicles.

The Tow Truck and Garbage Trucks have no sirens, but have refit options to non-CC paint schemes; they come in Company Color by default.

AI-built Tow Trucks and Garbage Trucks are by default Company-Colored. There is a parameter that determines whether AI-build vehicles should be
Company-Colored or not. This parameter is set to "Company Colored" by default. Horses & Riders are always CC, regardless of this setting.

Horses & riders feature company color and a 3-frame animation. They come in 3 different random variants of horses: brown, grey, and black.
They are available from the 17th century until the 1930s or so.

Finally, there are parameters to enable/disable each vehicle individually, in the event you only want some of these vehicles in your game.


-------
License
-------

This GRF is released under the CC BY-NC-SA license. See the license.txt file included in the grf package, or click the
"License" button in OTTD for more information.


-------
Credits
-------

This GRF was authored by Supercheese.

Translations contributed by:

English (UK): 	Pingaware
English (AU):   Flygon
Dutch:			Mahoo76
Polish: 		wojteks86
German:			Jogio
Slovak:			Gego
Malay:			SkiddLow
Swedish:		Joel A
French:			Grand Gorfou a.k.a. Pascal.Lambert@Sidel.Com

The sound effects were obtained from freesound.org, and are CC BY-NC Licensed.

The Garbage Truck sprites are modified from a Simutrans Pakset licensed under the Artistic License.
For the full text of the Artistic License, see: http://www.ncftp.com/ncftp/doc/LICENSE.txt

The police car sprites (both variants) are modified from Civilization 3 mods posted at the CivFanatics website:
http://forums.civfanatics.com/downloads.php?do=file&id=8760
http://forums.civfanatics.com/downloads.php?do=file&id=19139

The horse & rider sprites are based on the horse graphics from eGRVTS by Zephyris: http://www.tt-forums.net/viewtopic.php?t=33415#p613694
eGRVTS is also licensed under the CC BY-NC-SA license, the same as this grf.

All other sprites are derived from 3D models downloaded from "Trimble 3D Warehouse (powered by Google)". The sprites were
rendered and then heavily edited to produce the final product. The license terms of Trimble 3D Warehouse
(http://sketchup.google.com/intl/en/3dwh/preview_tos.html) state:

	Rights granted to other end users of the Services.
	You give other end users of the Services a perpetual, sublicensable, irrevocable, worldwide, royalty-free, and
	non-exclusive license to reproduce, adapt, modify, translate, publish, publicly perform, publicly display and
	distribute Existing Geolocated Models, Existing Non-Geolocated Models, New Models and related content and derivative
	works thereof which you submit, post or display on or through, the Services.



Many thanks are extended to the developers of OTTD and NML for creating and maintaining such wonderful free software.
