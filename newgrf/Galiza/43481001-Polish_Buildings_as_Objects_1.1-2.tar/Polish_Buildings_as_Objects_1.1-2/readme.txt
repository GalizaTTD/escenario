+-----------------------------+
| POLISH BUILDINGS AS OBJECTS |
+-----------------------------+


=== Description ===

This NewGRF was made from sprites of the beautiful "Polish Building Set 0.1".
Most buildings of that polish set (while still work in progress) had their snow variants, so these were appreciatively utilized as well, making the objects of this GRF mostly snow-aware (exceptions are indicated in the Object Selection menu).

Several buildings are company-coloured and few objects are multi-items, both cases are also noted in the Object Selection menu.



=== Parameters ===

-> Only in Scenario Editor = Objects can be placed only when creating a scenario.
-> Irremovable objects     = Built objects (in the editor or otherwise) can be removed only by using Magic bulldozer.



=== Credits ===

Original graphics by Sojita and TadeuszD of openttd-polska.pl.
Minor changes, additions and coding by chujo.

Licensed under the GNU General Public License version 2.



=== More info ===

@chujo on OpenTTD's Discord (discord.gg/openttd)
or www.tt-forums.net/viewtopic.php?t=91127