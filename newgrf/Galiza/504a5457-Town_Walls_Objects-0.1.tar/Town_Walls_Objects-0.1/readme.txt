Town Walls Objects V0.1
-----------------------------------

Contents:

1 About
2 Requirements
3 Installation
4 Usage
5 License
6 Credits




-------
1 About
-------

The Town Walls Objects Set provides a lot of (modular) object tiles to create your own medieval city walls and medieval/17th-century city centers.

See development thread for more information and screenshots: http://www.tt-forums.net/viewtopic.php?f=26&t=74515

Town Walls Objects V0.1
Name: townwalls_v0_1.grf
Version:  0.1
GRF ID:   50 4A 54 57





--------------
2 Requirements
--------------

Recommended is to use the latest (nightly)release of OpenTTD.



--------------
3 Installation
--------------

Copy the Town Walls Objects .grf file to the OpenTTD data directory. The OpenTTD readme explains where you can find this directory.

The final step is to activate the Town Walls Objects.
This is done via the NewGRF Settings window, which is explained here:
http://wiki.openttd.org/NewGRF.
Now you can use the Town Walls Objects in your new games.



-------
4 Usage
-------

These new object tiles can be used to give a medieval/17th-century feel to your game. 
The walls have been coded in such a way that they can be placed on water, so also on rivers/canals to create a moat around them.
There are also overlapping/drive-through tiles included, so your vehicles can enter the old town ;-)



---------
5 License
---------

Twon Walls Object Tiles for OpenTTD
Copyright (C) 2016 Quast65

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



---------
6 Credits
---------

Coding, Graphics alterations and new graphics by Quast65: http://www.tt-forums.net/viewtopic.php?f=26&t=57266

Many thanks to:

verdennis, the original graphics artist of the walls
meslinjf, who made almost all of the alterations to verdennis' graphics
Caelan, the original graphics artist of the Dutch style houses and canals
The Developers of the OpenGFX-Graphics Base Set, I used some of their roofs for some of the buildings and some of the brick walls for the canal walls and other textures.

If I have forgotten someone, my apologies, please contact me and you will be added: http://www.tt-forums.net/memberlist.php?mode=viewprofile&u=57156
 




























