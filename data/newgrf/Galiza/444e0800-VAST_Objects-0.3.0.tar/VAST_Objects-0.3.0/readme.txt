﻿========================================================================
                       VAST Objects 0.3.0 Readme                       
========================================================================
A set of NewObjects for OpenTTD.

----------------
Readme Contents:
----------------
1  About this Set
 1.1  Parameters
2  Installation
3  Compatibility
4  Feedback and Bug Reports
5  Contacting the Author / Obtaining the Source
6  License

========================================================================
    1: About this Set
========================================================================
This set provides NewObjects for OpenTTD, which are non-functional 
objects that act as eye candy. You can use them to style a particular
area of the map.

---------------
1.1: Parameters
---------------
This set uses parameters to customise some aspects of its behaviour. If
you want to change the parameters, do this before starting a new game 
from the menu. Changing parameters during a running game may have 
undesirable behaviour and is not supported.

The following parameters are available:

1 -> Remove VAST prefix from menus
Options >> Enabled [default]
        >> Disabled 
           If enabled, object classes won't have the prefix "VAST" in 
           the construction menu. It's probably neater like this.

2 -> Object removal behaviour
Options >> Owned-land [default]
        >> Normal
           Determines the behaviour of object removal in normal games 
           and in the scenario editor. Normal behaviour requires that 
           objects be removed using the demolition tool; owned-land 
           behaviour allows objects to be built over by their owners.

3 -> Construction cost multiplier
Options >> Any positive integer input up to 255 [default: 2]
           Construction costs for all objects in this set are multiplied
           by this value. The total cost of building an object in this 
           set also depends on the cost of clearing the tile, game 
           difficulty and inflation.

4 -> Removal cost multiplier
Options >> Any positive integer input up to 255 [default: 4]
           Removal costs for all objects in this set are multiplied by 
           this value. The total cost of removing an object in this set 
           also depends on the game difficulty and inflation.

========================================================================
    2: Installation
========================================================================
If you clicked "View readme" from within OpenTTD, VAST Objects is 
already installed. Otherwise do one of the following:

Method 1:
    Download from the online content service
    1: Start OpenTTD
    2: Click on "NewGRF Settings" > "Check Online Content"
    3: Search for "VAST Objects". 
    4: Tick the box to the left of the set's name and click Download.
    5: Close this window. Click "Add" and find VAST Objects in the 
       list of NewGRFs. Select it and click "Add to selection"
    6: Click "Apply changes"
    7. Start a new game.

Method 2:
    Manual Download
    1: Download a release from 
       https://www.tt-forums.net/viewtopic.php?f=67&t=48762
    2: Extract the GRF file from the package.
    3: Place the GRF file in OpenTTD's data directory. The location 
       depends on your OS:
         Windows: My Documents\OpenTTD
         Linux: ~/.openttd
         Mac: ~/Documents/OpenTTD
    4: Start OpenTTD
    5: Click on "NewGRF Settings"
    6: Click "Add" and find VAST Objects in the list of NewGRFs. 
       Select it and click "Add to selection"
    7: Click "Apply changes"
    8: Start a new game

========================================================================
    3: Compatibility
========================================================================
VAST Objects 0.3.0 requires OpenTTD r25230. It is not compatible with 
earlier versions of VAST Objects.

========================================================================
    4: Feedback and Bug Reports
========================================================================
Please report any bugs in this set's thread at 
http://www.tt-forums.net/viewtopic.php?f=67&t=48762
Any feedback (good or bad) would be greatly appreciated.

========================================================================
    5: Contacting the Author / Obtaining the Source
========================================================================
I can be contacted on the Transport Tycoon Forums at 
http://www.tt-forums.net under the username zero.eight.
The source is available from 
http://dev.openttdcoop.org/projects/vast

========================================================================
    6: License
========================================================================
Copyright (C) 2011-2013 David Nicholls

This program is free software; you can redistribute it and/or modify it 
under the terms of the GNU General Public License version 2 as 
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details.

A copy of the GNU General Public License v2 should be distributed along 
with this program in the file "license.txt"; if not, write to the Free 
Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
02110-1301, USA. 

========================================================================