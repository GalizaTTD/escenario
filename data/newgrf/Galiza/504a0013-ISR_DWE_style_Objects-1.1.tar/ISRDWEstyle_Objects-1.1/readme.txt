ISR/DWE-style objects v1.1
-----------------------------------

Contents:

1 About
2 Requirements
3 Installation
4 Usage
5 License
6 Credits




-------
1 About
-------

ISR/DWE-style objects is a feature that has loads of graphics converted from the ISR and DWE stations-sets to objects. Also a lot of new features, like dock- and road-overlapping tiles, drive-through tiles and new graphics.

ISR/DWE-style objects v1.1
Name: isrdwe_objects_v1_1.grf
Version:  1.1
GRF ID:   50 4A 00 13





--------------
2 Requirements
--------------

Recommended is to use the latest (nightly)release of OpenTTD and also use it in combination with the ISR-style dock GRF that provides an empty dock, so that you can change the appearance of the dock via dock overlapping tiles.
More info on that dock GRF and the ISR/DWE-style objects GRF can be found in the release thread: 
http://www.tt-forums.net/viewtopic.php?f=26&t=58884



--------------
3 Installation
--------------

Copy the ISR/DWE-style objects .grf file to the OpenTTD data directory. The OpenTTD readme explains where you can find this directory.

The final step is to activate the grf.
This is done via the NewGRF Settings window, which is explained here:
http://wiki.openttd.org/NewGRF.
Now you can use the grf in your new games.



-------
4 Usage
-------

To minimize the number of object-ID's, a lot of objects are under a single view. 
You can get the different representations of the object by multiple placement of the object on the same spot. The sequence in which they appear is sadly random (not possible yet to have it in a numbered sequence), so you might need a couple of clicks until you get the tile you want ;-)
These objects are representated in the menu via miniviews inside the menu view itself.




---------
5 License
---------

ISR/DWE-style objects for OpenTTD
Copyright (C) 2013 Quast65

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



---------
6 Credits
---------

- Developed and coded by Quast65
- New and altered graphics by Quast65
- Original foundations made by SAC
- Original ISR-graphics by the developers of the ISR-set
- Original DWE-graphics by the developers of the DWE-set
- Original trucks by the developers of the LRV-set
- Original ships by lead@inbox and the developers of the FISH-set
- Original tramtracks by Foobar
- Original OpenGFX-graphics by the developers of the OpenGFX-set
- Many thanks to Wallyweb for his help with parts of the code

