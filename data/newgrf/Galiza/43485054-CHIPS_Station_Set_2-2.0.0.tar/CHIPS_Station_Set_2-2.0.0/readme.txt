CHIPS Has Improved Players' Stations
-------------------------------------
Simple stations and station tiles.
Features magic sprinkles to provide buffer stops, cargo graphics and random eye candy.

Includes a dock that matches the station tiles.

Goes great with:
- FIRS industry set
- Stations in original TTD graphics
- Mayonnaise + Ketchup

-----------------
More about CHIPS
-----------------

For latest information / releases, visit TT-Forums.
Release thread: 
	http://www.tt-forums.net/viewtopic.php?f=67&t=53362
Development thread:
	http://www.tt-forums.net/viewtopic.php?f=26&t=53348

---------
Authors
---------

CHIPS by andythenorth and yexo.
Build framework by planetmaker.
Small truck graphic by pikka.
Station Hotel graphic by DanMacK.
Dock code by PaulC.
Contains graphics from ISR used under GPL.

Special thanks to #openttdcoop.

Special thanks to anyone I've forgotten :o

Contact me via the forums at http://tt-forums.net - username andythenorth

---------
License
---------

CHIPS Station Set - for OpenTTD
Copyright (C) 2011-2020  andythenorth, planetmaker, yexo

Released under the GNU General Public license v2 or later. See license.txt

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

The source code can be obtained from the #openttdcoop DevZone at 
	http://dev.openttdcoop.org/projects/chips 
or via mercurial checkout
	hg clone http://dev.openttdcoop.org/projects/chips
