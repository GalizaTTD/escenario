This grf is adapted from opengfx+ airports.

Origional graphics and code by:

Authors:
    Lead programmer:            Thijs Marinussen (aka Yexo)
    General coding:             David Nicholls (aka zero.eight)
    General coding:             Ingo von Borstel (aka planetmaker)

    Availability parameter:     Supercheese

Graphics:
    generally                   zero.eight
    original OpenGFX:           Skidd13, Zephyris
    large airport depots:       2006TTD
    small airport depot facing
        viewer with backside:   planetmaker
    180° preview small airport: planetmaker
    0° preview small airport:   Rubidium
